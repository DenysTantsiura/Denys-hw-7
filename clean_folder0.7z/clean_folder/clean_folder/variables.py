known_extensions = []
unknown_extensions = []

images = []
documents = []
audio = []
video = []
archives = []
